﻿using EVA_WPF.ViewModel;
using SUNLC6_GameOfLife.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;

namespace EVA_WPF
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public App()
        {
            var model = new GameViewModel(19);
            var view = new MainWindow();
            view.DataContext = model;
            view.Show();
        }
    }
}
