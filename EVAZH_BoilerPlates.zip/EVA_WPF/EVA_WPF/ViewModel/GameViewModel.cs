﻿using SUNLC6_GameOfLife.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace EVA_WPF.ViewModel
{
    internal class GameViewModel : INotifyPropertyChanged
    {

        private int TableSize { get; set; }
        //public RowDefinitionCollection GameTableRows
        //{
        //    get => new RowDefinitionCollection(Enumerable.Repeat(new RowDefinition(GridLength.Auto), TableSize).ToArray());
        //}
        //public ColumnDefinitionCollection GameTableColumns
        //{
        //    get => new ColumnDefinitionCollection(Enumerable.Repeat(new ColumnDefinition(GridLength.Auto), TableSize).ToArray());
        //}
        private Game _currentGame { get; set; }
        public ObservableCollection<GameField> Fields { get; set; }
        public bool alreadyRunning = false;

        public DelegateCommand? StopGameCommand { get; set; }
        public DelegateCommand? StartGameCommand { get; set; }

        private DispatcherTimer timer;

        public GameViewModel(int size)
        {
            TableSize = size;
            Fields = new ObservableCollection<GameField>();
            _currentGame = new Game(TableSize);
            _currentGame.FieldChanged += FieldChanged;
            StartGameCommand = new DelegateCommand(p => StartGame());
            StopGameCommand = new DelegateCommand(p => StopGame());

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += (s, e) => _currentGame.IterateGame();


            foreach (var field in _currentGame.gameField)
            {
                Fields.Add(new GameField()
                {
                    X = field.PosX,
                    Y = field.PosY,
                    IsEnabled = true,
                    //FColor = field.IsDead ? Color.FromRgb(0, 0, 0) : Color.FromRgb(255, 255, 255),
                    ClickedCommand = new DelegateCommand(p =>
                    {
                        if (p is string param)
                            ChangeField(param);
                    })
                });
            }

        }


        private void StopGame()
        {
            alreadyRunning = false;
            foreach (var item in Fields)
            {
                item.changeE();
            }
            timer.Stop();
        }

        private void FieldChanged(object? sender, string? pos)
        {
            var data = pos.Split(';').Select(int.Parse);
            //Fields.First(f => f.XY == pos).ChangeColor();
        }

        private void ChangeField(string pos)
        {
            var data = pos.Split(';').Select(int.Parse).ToList();
            _currentGame.changeField(data[0], data[1]);
            
        }

        public void StartGame()
        {
            if (alreadyRunning) return;
            alreadyRunning = true;
            foreach (var item in Fields)
            {
                item.changeE();
            }
            timer.Start();
        }




        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
