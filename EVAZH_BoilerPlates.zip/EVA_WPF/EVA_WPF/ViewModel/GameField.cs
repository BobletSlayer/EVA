﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace EVA_WPF.ViewModel
{
    public class GameField : INotifyPropertyChanged
    {
        private int x;
        public int X
        {
            get { return x; }
            set { x = value; OnPropertyChanged(nameof(Y)); }
        }

        private int y;
        public int Y
        {
            get { return y; }
            set { y = value; OnPropertyChanged(nameof(Y)); }
        }

        public string XY { get => $"{X};{Y}"; }



        private bool isEnabled;
        public bool IsEnabled
        {
            get { return isEnabled; }
            set { isEnabled = value; OnPropertyChanged(nameof(IsEnabled)); }
        }

        public DelegateCommand? ClickedCommand { get; set; }



        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public void changeE()
        {
            IsEnabled = !IsEnabled;
            OnPropertyChanged(nameof(IsEnabled));

        }

    }
}
