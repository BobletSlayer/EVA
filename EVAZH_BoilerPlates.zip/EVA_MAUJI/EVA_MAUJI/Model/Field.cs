﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SUNLC6_GameOfLife.Model
{
    public class Field
    {
        public int PosX { get; set; }
        public int PosY { get; set; }
        public bool IsDead { get; set; }

        public Field(int x, int y, bool d)
        {
            PosX = x;
            PosY = y;
            IsDead = d;
        }
        public bool changeIsDead()
        {
            IsDead = !IsDead;
            return IsDead;
        }
    }
}
