﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace SUNLC6_GameOfLife.Model
{
    internal class Game
    {

        public event EventHandler<string>? FieldChanged;
        public List<Field> gameField { get; set; }
        private List<List<Field>> existingPositions {  get; set; }
        private int Size { get; set; }
        public Game(int size)
        {
            Size = size;
            gameField = new List<Field>();
            existingPositions = new List<List<Field>>();
            //Create empty gameField
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    gameField.Add(new Field(i, j, true));
                }
            }
            //!!!
            existingPositions.Add(gameField);
        }

        private int AdjacentAliveCount(int x, int y)
        {
            return gameField
                .Where(
                w =>
                (w.PosX == x - 1 && x >0) ||
                (w.PosY == y - 1 && y > 0) ||
                (w.PosX == x + 1 && x < Size) ||
                (w.PosX == y + 1 && y < Size) ||
                (w.PosX == x - 1 && w.PosY == y - 1) ||
                (w.PosX == x - 1 && w.PosY == y + 1) ||
                (w.PosX == x + 1 && w.PosY == y - 1) ||
                (w.PosX == x + 1 && w.PosY == y + 1)
                )
                .Count(f => !f.IsDead);
        }

        public bool IterateGame()
        {
            // 0 = no change; 1 = dies; 2 = revives
            int[,] changes = new int[Size,Size];
            gameField.ForEach(f =>
            {
                int adj = AdjacentAliveCount(f.PosX,f.PosY);
                if ((adj ==0 || adj == 1) && !f.IsDead) changes[f.PosX, f.PosY] = 1;
                if ((adj >=4) && !f.IsDead) changes[f.PosX, f.PosY] = 1;
                if ((adj == 2 || adj == 3) && !f.IsDead) changes[f.PosX, f.PosY] = 0;
                if ((adj == 3) && f.IsDead) changes[f.PosX, f.PosY] = 2;
            });
            foreach (var field in gameField)
            {
                if (changes[field.PosX, field.PosY] != 0) { 
                    if (changes[field.PosX, field.PosY] == 1)
                    {
                        field.IsDead = true;
                    }
                    else if (changes[field.PosX, field.PosY] == 2)
                    {
                        field.IsDead = false;
                    }
                    FieldChanged.Invoke(this,$"{field.PosX};{field.PosY}");
                }
            }
            return InfiniteLoop();
        }

        public void changeField(int x, int y)
        {
            gameField.First(f=>f.PosX == x && f.PosY == y).changeIsDead();
            
            FieldChanged.Invoke(this,$"{x};{y}");
        }
        private bool InfiniteLoop()
        {
            return false;
        }
    }
}
