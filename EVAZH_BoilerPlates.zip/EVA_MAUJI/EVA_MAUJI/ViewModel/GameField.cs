﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace SUNLC6_GameOfLife.ViewModel
{
    public class GameField : INotifyPropertyChanged
	{
		private int x;
		public int X
		{
			get { return x; }
			set { x = value; OnPropertyChanged(nameof(Y)); }
		}

		private int y;
		public int Y
		{
			get { return y; }
			set { y = value; OnPropertyChanged(nameof(Y)); }
		}

		public string XY { get => $"{X};{Y}"; }

		private Color fcolor;
		public Color FColor
		{
			get { return fcolor; }
			set { fcolor = value; OnPropertyChanged(nameof(Color)); }
		}

		private bool isEnabled;
		public bool IsEnabled
		{
			get { return isEnabled; }
			set { isEnabled = value; OnPropertyChanged(nameof(IsEnabled)); }
		}

        public DelegateCommand? ClickedCommand { get; set; }



        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] String? propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

		public void changeE()
		{
			IsEnabled = !IsEnabled;
			OnPropertyChanged(nameof(IsEnabled));

		}
        public void ChangeColor()
        {
			if (this.FColor.Equals(Color.FromRgb(0,0,0))) this.FColor = Color.FromRgb(255,255,255);
			else this.FColor = Color.FromRgb(0, 0, 0);

			OnPropertyChanged(nameof(FColor));
        }
    }
}
