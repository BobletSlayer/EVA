namespace SUNLC6_GameOfLife.View;

public partial class GamePage : ContentPage
{
	public GamePage()
	{
		InitializeComponent();
	}
}