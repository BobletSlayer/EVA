﻿using SUNLC6_GameOfLife.View;
using SUNLC6_GameOfLife.ViewModel;

namespace EVA_MAUJI
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();

            var model = new GameViewModel(12);
            MainPage = new GamePage()
            {
                BindingContext = model
            };
        }
    }
}