using MineSweeperLib.Model;

namespace EVA_WINFORMS
{
    public partial class Form1 : Form
    {

        private Game? currentGame;
        private MenuStrip? menu;
        private Label? playerLabel;
        private List<Button> buttons = new List<Button>();
        public Form1()
        {
            InitializeComponent();

            InitMenu();
            CreateMenu();
        }
        private void InitMenu()
        {
            var menustrip = new MenuStrip();

            var gamesStrip = new ToolStripMenuItem();
            gamesStrip.Text = "�j J�t�k";
            gamesStrip.Click += NewGame;

            //var strip6x6 = new ToolStripMenuItem();
            //strip6x6.Text = "6x6";
            //strip6x6.Click += New6x6Game;

            //var strip10x10 = new ToolStripMenuItem();
            //strip10x10.Text = "10x10";
            //strip10x10.Click += New10x10Game;

            //var strip16x16 = new ToolStripMenuItem();
            //strip16x16.Text = "16x16";
            //strip16x16.Click += New16x16Game;

            //gamesStrip.DropDownItems.Add(strip6x6);
            //gamesStrip.DropDownItems.Add(strip10x10);
            //gamesStrip.DropDownItems.Add(strip16x16);
            menustrip.Items.Add(gamesStrip);


            //var saveStrip = new ToolStripMenuItem();
            //saveStrip.Text = "J�t�k ment�se";
            //saveStrip.Click += Save;
            //menustrip.Items.Add(saveStrip);

            //var loadStrip = new ToolStripMenuItem();
            //loadStrip.Text = "J�t�k Bet�lt�se";
            //loadStrip.Click += LoadSFile;
            //menustrip.Items.Add(loadStrip);

            playerLabel = new Label();
            playerLabel.Text = "";
            playerLabel.Size = new Size(200, 30);
            playerLabel.Location = new Point(this.Size.Width / 2, 30);
            Controls.Add(playerLabel);

            this.menu = menustrip;
        }
        private void CreateMenu()
        {
            Controls.Add(menu);

        }

        private void NewGame(object? sender, EventArgs e)
        {
            ClearField();

            this.currentGame = new Game(12, 12, 10);
            currentGame.FieldRevealedEvent += this.FieldRevealed;
            GenerateGamePanel();
        }

        private void ClearField()
        {
            if (playerLabel != null)
                playerLabel.Text = string.Empty;
            foreach (var item in buttons)
            {
                Controls.Remove((Control)item);
            }
            buttons.Clear();
            currentGame = null;
        }


        private void GenerateGamePanel()
        {
            if (currentGame == null) return;
            if (playerLabel != null) playerLabel.Text = $"{currentGame.CurrentPlayer} K�vetkezik";
            for (int i = 0; i < currentGame.XLength; i++)
            {
                for (int j = 0; j < currentGame.YLength; j++)
                {
                    var btn = new NoSelectButton();
                    btn.Name = $"{i};{j}";
                    btn.Size = new Size(50, 50);
                    btn.Location = new Point(i * 50 + 30, j * 50 + 60);
                    btn.BackColor = Color.DarkGray;
                    btn.Click += ButtonClicked;

                    buttons.Add(btn);
                    Controls.Add(btn);
                }
            }
        }
        private void ButtonClicked(object? sender, EventArgs e)
        {
            if (sender is not Button) return;
            var pos = ((Button)sender).Name.Split(';');
            try
            {
                currentGame?.PlayerMove(int.Parse(pos[0]), int.Parse(pos[1]));
                if (playerLabel != null && currentGame != null) playerLabel.Text = $"{currentGame.CurrentPlayer} K�vetkezik";

            }
            //
            catch (DrawGameException)
            {
                if (playerLabel != null) playerLabel.Text = string.Empty;
                MessageBox.Show("A j�t�k D�ntetlen");
                ClearField();
            }
            catch (GameOverException)
            {
                if (playerLabel != null) playerLabel.Text = string.Empty;
                MessageBox.Show($"{currentGame?.CurrentPlayer} Vesztett");
                ClearField();
            }

        }

        private void FieldRevealed(object? sender, RevealedEventArgs e)
        {
            var btn = (Button)Controls[$"{e.x};{e.y}"];
            btn.BackColor = Color.LightGray;
            if (e.neighbours > 0)
            {
                btn.Text = e.neighbours.ToString();
            }
            if (e.neighbours >= 3)
            {
                btn.ForeColor = Color.Pink;
            }
            btn.Enabled = false;

        }

        private void Form1_SizeChanged(object sender, EventArgs e)
        {
            if (playerLabel != null) playerLabel.Location = new Point(this.Size.Width / 2 - (playerLabel.Width / 2), 30);
        }


    }
    class NoSelectButton : Button
    {
        public NoSelectButton()
        {
            SetStyle(ControlStyles.Selectable, false);
        }
    }
}


