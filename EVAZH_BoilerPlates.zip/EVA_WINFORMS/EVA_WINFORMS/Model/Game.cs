﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Security.Cryptography.Xml;
using System.Text;
using System.Threading.Tasks;

namespace MineSweeperLib.Model
{
    public class Game
    {
        private IField[,] board;
        private string[] Players = new string[] { "Játékos 1", "Játékos 2" };
        private int currentplayerIndex = 0;
        public string CurrentPlayer { get => this.Players[currentplayerIndex]; }
        public int XLength { get => board.GetLength(0); }
        public int YLength { get => board.GetLength(1); }

        public event EventHandler<RevealedEventArgs>? FieldRevealedEvent;

        /// <summary>
        /// Create game from save file
        /// </summary>
        /// <param name="savedString">Content of save file</param>
        private Game(string savedString)
        {
            var data = savedString.Split('\n');
            this.currentplayerIndex = int.Parse(data[0]);
            var dimensions = data[1].Split(';');
            board = new IField[int.Parse(dimensions[0]), int.Parse(dimensions[1])];
            string[][] arrayData = data.Skip(2).Select(s => s.Split(';')).ToArray();
            for (int i = 0; i < board.GetLength(0); i++)
            {
                for (int j = 0; j < board.GetLength(1); j++)
                {
                    if (arrayData[i][j] == "x") board[i, j] = new Bomb();
                    else if (arrayData[i][j][0] == 'r')
                    {
                        board[i, j] = new EmptyField();
                        (board[i, j] as EmptyField)!.SetRevealed();
                        for (int k = 0; k < int.Parse(arrayData[i][j].Substring(1)); k++)
                        {
                            (board[i, j] as EmptyField)!.AddToNeighboringBombCount();
                        }
                    }
                    else
                    {
                        board[i, j] = new EmptyField();
                        for (int k = 0; k < int.Parse(arrayData[i][j]); k++)
                        {
                            (board[i, j] as EmptyField)!.AddToNeighboringBombCount();
                        }
                    }

                }
            }
        }
        /// <summary>
        /// Create new game
        /// </summary>
        /// <param name="x">row count</param>
        /// <param name="y">column count</param>
        /// <param name="bombCount">bomb count</param>
        public Game(int x, int y, int bombCount)
        {
            board = new IField[x, y];
            Random rnd = new Random(DateTime.Now.Millisecond);

            //Generating bomb positions
            var bombPositions = new (int? x, int? y)[bombCount];
            int ind = 0;
            while (ind < bombCount)
            {
                //(int, int) temp;
                int tempx, tempy;
                bool alreadyInArray = false;
                do
                {
                    alreadyInArray = false;
                    tempx = rnd.Next(0, x);
                    tempy = rnd.Next(0, y);
                    alreadyInArray = bombPositions.Any(f => f.x == tempx && f.y == tempy);
                } while (alreadyInArray);

                bombPositions[ind] = (tempx, tempy);
                board[tempx, tempy] = new Bomb();
                ind++;
            }

            //Placing down fields and calculating nearby bombs
            for (int i = 0; i < x; i++)
            {
                for (int j = 0; j < y; j++)
                {
                    if (board[i, j] is not Bomb)
                    {
                        board[i, j] = new EmptyField();


                        if (i > 0 && board[i - 1, j] is Bomb) ((EmptyField)board[i, j]).AddToNeighboringBombCount();
                        if (i < x - 1 && board[i + 1, j] is Bomb) ((EmptyField)board[i, j]).AddToNeighboringBombCount();
                        if (j > 0 && board[i, j - 1] is Bomb) ((EmptyField)board[i, j]).AddToNeighboringBombCount();
                        if (j < y - 1 && board[i, j + 1] is Bomb) ((EmptyField)board[i, j]).AddToNeighboringBombCount();


                        if (i > 0 && j > 0 && board[i - 1, j - 1] is Bomb) ((EmptyField)board[i, j]).AddToNeighboringBombCount();
                        if (i > 0 && j < y - 1 && board[i - 1, j + 1] is Bomb) ((EmptyField)board[i, j]).AddToNeighboringBombCount();
                        if (i < x - 1 && j > 0 && board[i + 1, j - 1] is Bomb) ((EmptyField)board[i, j]).AddToNeighboringBombCount();
                        if (i < x - 1 && j < y - 1 && board[i + 1, j + 1] is Bomb) ((EmptyField)board[i, j]).AddToNeighboringBombCount();
                    }
                }
            }

        }
        // Execute move
        public string PlayerMove(int x, int y)
        {
            Reveal(x, y);
            if (AllRevealed()) throw new DrawGameException($"Draw");
            currentplayerIndex = (currentplayerIndex + 1) % 2;
            return $"{x}";
        }
        //Reveal field or explode Bomb
        private void Reveal(int x, int y)
        {
            try
            {
                if (board[x, y].Reveal() == 0)
                {
                    RevealNeighbours((x, y));
                }
                FieldRevealedEvent?.Invoke(this, new RevealedEventArgs(x, y, ((EmptyField)this.board[x, y]).NeighboringBombCount));
            }
            catch (GameOverException)
            {
                throw new GameOverException($"{Players[currentplayerIndex]} lost!");
            }
        }
        // Reveal fields while not exploding bombs
        private void RReveal(int x, int y)
        {
            if (board[x, y] is not Bomb && !board[x, y].IsRevealed && board[x, y].Reveal() == 0)
            {
                RevealNeighbours((x, y));
            }
            FieldRevealedEvent?.Invoke(this, new RevealedEventArgs(x, y, ((EmptyField)this.board[x, y]).NeighboringBombCount));

        }
        private void RevealNeighbours((int x, int y) item)
        {

            if (item.x > 0 && board[item.x - 1, item.y] is EmptyField && !board[item.x - 1, item.y].IsRevealed) RReveal(item.x - 1, item.y);
            if (item.x < board.GetLength(0) - 1 && board[item.x + 1, item.y] is EmptyField && !board[item.x + 1, item.y].IsRevealed) RReveal(item.x + 1, item.y);

            if (item.y > 0 && board[item.x, item.y - 1] is EmptyField && !board[item.x, item.y - 1].IsRevealed) RReveal(item.x, item.y - 1);
            if (item.y < board.GetLength(1) - 1 && board[item.x, item.y + 1] is EmptyField && !board[item.x, item.y + 1].IsRevealed) RReveal(item.x, item.y + 1);

            if (item.x > 0 && item.y > 0 && board[item.x - 1, item.y - 1] is EmptyField && !board[item.x - 1, item.y - 1].IsRevealed) RReveal(item.x - 1, item.y - 1);
            if (item.x > 0 && item.y < board.GetLength(1) - 1 && board[item.x - 1, item.y + 1] is EmptyField && !board[item.x - 1, item.y + 1].IsRevealed) RReveal(item.x - 1, item.y + 1);

            if (item.x < board.GetLength(0) - 1 && item.y > 0 && board[item.x + 1, item.y - 1] is EmptyField && !board[item.x + 1, item.y - 1].IsRevealed) RReveal(item.x + 1, item.y - 1);
            if (item.x < board.GetLength(0) - 1 && item.y < board.GetLength(1) - 1 && board[item.x + 1, item.y + 1] is EmptyField && !board[item.x + 1, item.y + 1].IsRevealed) RReveal(item.x + 1, item.y + 1);
        }

        private bool AllRevealed()
        {
            for (int i = 0; i < board.GetLength(0); i++)
            {
                for (int j = 0; j < board.GetLength(1); j++)
                {
                    if (board[i, j] is EmptyField && !board[i, j].IsRevealed) return false;
                }
            }
            return true;
        }

        public string ExportSaveString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append($"{currentplayerIndex}\n");
            sb.Append($"{board.GetLength(0)};{board.GetLength(1)}\n");
            for (int i = 0; i < board.GetLength(0); i++)
            {
                for (int j = 0; j < board.GetLength(1); j++)
                {
                    if (board[i, j] is Bomb) sb.Append(j == board.GetLength(1) - 1 ? "x" : "x;");
                    else
                    if (board[i, j] is EmptyField && board[i, j].IsRevealed) sb.Append(j == board.GetLength(1) - 1 ? $"r{((EmptyField)board[i, j]).NeighboringBombCount}" : $"r{((EmptyField)board[i, j]).NeighboringBombCount};");
                    else
                    if (board[i, j] is EmptyField) sb.Append(j == board.GetLength(1) - 1 ? $"{((EmptyField)board[i, j]).NeighboringBombCount}" : $"{((EmptyField)board[i, j]).NeighboringBombCount};");
                }
                if (i != board.GetLength(0) - 1) sb.Append('\n');
            }
            return sb.ToString();
        }
        public static Game ImportSaveString(string savedString)
        {
            return new Game(savedString);
        }
        /// <summary>
        /// Sends out events for all the revealed fields
        /// </summary>
        public void InvokeRevealed()
        {
            for (int i = 0; i < board.GetLength(0); i++)
            {
                for (int j = 0; j < board.GetLength(1); j++)
                {
                    if (board[i, j] != null && board[i, j] is EmptyField && board[i, j].IsRevealed)
                        FieldRevealedEvent?.Invoke(this, new RevealedEventArgs(i, j, (board[i, j] as EmptyField)!.NeighboringBombCount));
                }
            }
        }

    }
    public class RevealedEventArgs : EventArgs
    {
        public int x { get; }
        public int y { get; }
        public int neighbours { get; }
        public RevealedEventArgs(int x, int y, int neighbours) : base()
        {
            this.y = y;
            this.x = x;
            this.neighbours = neighbours;

        }
    }

}
