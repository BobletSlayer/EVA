﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MineSweeperLib.Model
{
    public class Bomb : IField
    {
        public bool IsRevealed { get; private set; } = true;

        public int Reveal()
        {
            throw new GameOverException();
        }
    }
}
