﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MineSweeperLib.Model
{
    public class EmptyField : IField
    {
        public int NeighboringBombCount { get; private set; } = 0;
        public bool IsRevealed { get; private set; } = false;

        public void AddToNeighboringBombCount()
        {
            NeighboringBombCount++;
        }

        public int Reveal()
        {
            this.IsRevealed = true;
            return NeighboringBombCount;
        }

        internal void SetRevealed()
        {
            this.IsRevealed = true;
        }
    }
}
