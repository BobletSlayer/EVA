﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace MineSweeperLib.Model
{
    public class DrawGameException : Exception
    {
        public DrawGameException()
        {
        }

        public DrawGameException(string? message) : base(message)
        {
        }

        public DrawGameException(string? message, Exception? innerException) : base(message, innerException)
        {
        }

        protected DrawGameException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
