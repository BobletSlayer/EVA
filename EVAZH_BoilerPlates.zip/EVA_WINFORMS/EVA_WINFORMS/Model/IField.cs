﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MineSweeperLib.Model
{
    public interface IField
    {
        public bool IsRevealed { get;}
        public int Reveal();

    }
}
